package com.example.commit.ListItem

data class Categoryitem (
    var categoryname:String?
)