/*
뒤로가기버튼
제목입력
내용입력
파일첨부
등록버튼
 */
package com.example.commit.MainActivity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.commit.R

class WriteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_write)
    }
}
