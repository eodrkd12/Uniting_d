package com.example.commit.ListItem

class DatingItem {
    var nickname:String?=null
    var department:String?=null
    var age:String?=null
}