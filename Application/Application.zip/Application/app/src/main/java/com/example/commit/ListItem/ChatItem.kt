package com.example.commit.ListItem

class ChatItem {
    var roomId : String? = null
    var speaker : String? = null
    var content : String? = null
    var time : String? = null
}