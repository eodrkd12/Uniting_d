package com.example.commit.ListItem

class UniversityItem{
    var university:String?=null
    var enable:Boolean=false
}