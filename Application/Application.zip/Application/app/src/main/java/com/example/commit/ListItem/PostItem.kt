package com.example.commit.ListItem

class PostItem {
    var title:String?=null
    var writer:String?=null
}