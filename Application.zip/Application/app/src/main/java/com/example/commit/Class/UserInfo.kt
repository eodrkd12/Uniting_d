package com.example.commit.Class

import android.app.Application
import android.graphics.Bitmap

class UserInfo :Application() {


    companion object{
        var ID : String=""
        var PW : String=""
        var NAME : String=""
        var BIRTH : String=""
        var GENDER : String=""
        var NICKNAME : String=""
        var EMAIL : String=""
        var UNIV : String=""
        var ENTER : String=""
        var DEPT : String=""
        var IMG : String=""

    }
}