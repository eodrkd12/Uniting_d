package com.example.commit.ListItem

class ChatRoomListItem {
    var roomId:String?=null
    var cateName:String?=null
    var maker:String?=null
    var roomTitle:String?=null
    var limitNum:Int?=null
    var universityName:String?=null
    var curNum:Int?=null
}