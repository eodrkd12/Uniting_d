package com.example.commit.ListItem

class DepartmentItem{
    var department:String?=null
    var enable:Boolean=false
}