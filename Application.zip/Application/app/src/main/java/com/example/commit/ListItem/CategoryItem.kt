package com.example.commit.ListItem

class CategoryItem {
    public var category: String? = null
}