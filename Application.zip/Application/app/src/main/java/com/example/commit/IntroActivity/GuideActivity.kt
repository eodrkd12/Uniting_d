/*
Guide Activity
1. 앱 사용 설명을 해주는 액티비티(여러개 생성 예정)
2. 다음버튼 -> 다음 GuideActivity로 전환
3. 마지막 GuideActivity 다음에는 LoginActivity로 전환
 */
package com.example.commit.IntroActivity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class GuideActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}