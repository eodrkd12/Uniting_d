/*
리스트뷰
뒤로가기
무음/진동/소리 (라디오버튼)
댓글알람 on/off
채팅알람 on/off
공지사항 on/off
 */
package com.example.commit.MainActivity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.commit.R

class AlarmActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm)
    }
}
